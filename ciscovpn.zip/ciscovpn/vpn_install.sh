#!/bin/sh
#

BASH_BASE_SIZE=0x00000000
# BASH_BASE_SIZE=0x00000000 required for signing
# comment after BASH_BASE_SIZE or signing tool will find comment

TARROOT="ciscovpn"
INSTPREFIX=/opt/cisco/vpn
ROOTCERTSTORE=/opt/.cisco/certificates/ca
ROOTCACERT="VeriSignClass3PublicPrimaryCertificationAuthority-G5.pem"
INIT="vpnagentd_init"
BINDIR=${INSTPREFIX}/bin
LIBDIR=${INSTPREFIX}/lib
PROFILEDIR=${INSTPREFIX}/profile
SCRIPTDIR=${INSTPREFIX}/script
UNINST=${BINDIR}/vpn_uninstall.sh
INSTALL=install
SYSVSTART="S85"
SYSVSTOP="K25"
SYSVLEVELS="2 3 4 5"
PREVDIR=`pwd`
MARKER=$((`grep -an "[B]EGIN\ ARCHIVE" $0 | cut -d ":" -f 1` + 1))
MARKER_END=$((`grep -an "[E]ND\ ARCHIVE" $0 | cut -d ":" -f 1` - 1))
LOGFNAME=`date "+anyconnect-Linux_64-2.5.3055-k9-%H%M%S%d%m%Y.log"`

echo "Installing Cisco AnyConnect VPN Client ..."
echo "Installing Cisco AnyConnect VPN Client ..." > /tmp/${LOGFNAME}
echo `whoami` "invoked $0 from " `pwd` " at " `date` >> /tmp/${LOGFNAME}

# Make sure we are root
if [ `id | sed -e 's/(.*//'` != "uid=0" ]; then
  echo "Sorry, you need super user privileges to run this script."
  exit 1
fi
## The web-based installer used for VPN client installation and upgrades does
## not have the license.txt in the current directory, intentionally skipping
## the license agreement. Bug CSCtc45589 has been filed for this behavior.   
if [ -f "license.txt" ]; then
    cat ./license.txt
    echo -e -n "\nDo you accept the terms in the license agreement? [y/n] "
    read LICENSEAGREEMENT
    while : 
    do
      case ${LICENSEAGREEMENT} in
           [Yy][Ee][Ss])
                   echo "You have accepted the license agreement."
                   echo "Please wait while Cisco Anyconnect VPN Client is being installed..."
                   break
                   ;;
           [Yy])
                   echo "You have accepted the license agreement."
                   echo "Please wait while Cisco Anyconnect VPN Client is being installed..."
                   break
                   ;;
           [Nn][Oo])
                   echo "The installation was cancelled because you did not accept the license agreement."
                   exit 1
                   ;;
           [Nn])
                   echo "The installation was cancelled because you did not accept the license agreement."
                   exit 1
                   ;;
           *)    
                   echo "Please enter either \"y\" or \"n\"."
                   read LICENSEAGREEMENT
                   ;;
      esac
    done
fi
if [ "`basename $0`" != "vpn_install.sh" ]; then
  if which mktemp >/dev/null 2>&1; then
    TEMPDIR=`mktemp -d /tmp/vpn.XXXXXX`
    RMTEMP="yes"
  else
    TEMPDIR="/tmp"
    RMTEMP="no"
  fi
else
  TEMPDIR="."
fi

#
# Check for and uninstall any previous version.
#
if [ -x "${UNINST}" ]; then
  echo "Removing previous installation..."
  echo "Removing previous installation: "${UNINST} >> /tmp/${LOGFNAME}
  STATUS=`${UNINST}`
  if [ "${STATUS}" ]; then
    echo "Error removing previous installation!  Continuing..." >> /tmp/${LOGFNAME}
  fi
fi

if [ "${TEMPDIR}" != "." ]; then
  TARNAME=`date +%N`
  TARFILE=${TEMPDIR}/vpninst${TARNAME}.tgz

  echo "Extracting installation files to ${TARFILE}..."
  echo "Extracting installation files to ${TARFILE}..." >> /tmp/${LOGFNAME}
  # "head --bytes=-1" used to remove '\n' prior to MARKER_END
  head -n ${MARKER_END} $0 | tail -n +${MARKER} | head --bytes=-1 2>> /tmp/${LOGFNAME} > ${TARFILE} || exit 1

  echo "Unarchiving installation files to ${TEMPDIR}..."
  echo "Unarchiving installation files to ${TEMPDIR}..." >> /tmp/${LOGFNAME}
  tar xvzf ${TARFILE} -C ${TEMPDIR} >> /tmp/${LOGFNAME} 2>&1 || exit 1

  rm -f ${TARFILE}

  NEWTEMP="${TEMPDIR}/${TARROOT}"
else
  NEWTEMP="."
fi

# Make sure destination directories exist
echo "Installing "${BINDIR} >> /tmp/${LOGFNAME}
${INSTALL} -d ${BINDIR} || exit 1
echo "Installing "${LIBDIR} >> /tmp/${LOGFNAME}
${INSTALL} -d ${LIBDIR} || exit 1
echo "Installing "${PROFILEDIR} >> /tmp/${LOGFNAME}
${INSTALL} -d ${PROFILEDIR} || exit 1
echo "Installing "${SCRIPTDIR} >> /tmp/${LOGFNAME}
${INSTALL} -d ${SCRIPTDIR} || exit 1
echo "Installing "${ROOTCERTSTORE} >> /tmp/${LOGFNAME}
${INSTALL} -d ${ROOTCERTSTORE} || exit 1

# Copy files to their home
echo "Installing "${NEWTEMP}/${ROOTCACERT} >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 444 ${NEWTEMP}/${ROOTCACERT} ${ROOTCERTSTORE} || exit 1

echo "Installing "${NEWTEMP}/vpn_uninstall.sh >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 755 ${NEWTEMP}/vpn_uninstall.sh ${BINDIR} || exit 1

echo "Installing "${NEWTEMP}/vpnagentd >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 4755 ${NEWTEMP}/vpnagentd ${BINDIR} || exit 1

echo "Installing "${NEWTEMP}/libssl.so.0.9.8 >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 755 ${NEWTEMP}/libssl.so.0.9.8 ${LIBDIR} || exit 1

echo "Installing "${NEWTEMP}/libcrypto.so.0.9.8 >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 755 ${NEWTEMP}/libcrypto.so.0.9.8 ${LIBDIR} || exit 1

if [ -f "${NEWTEMP}/vpnui" ]; then
    echo "Installing "${NEWTEMP}/vpnui >> /tmp/${LOGFNAME}
    ${INSTALL} -o root -m 755 ${NEWTEMP}/vpnui ${BINDIR} || exit 1
else
    echo "${NEWTEMP}/vpnui does not exist. It will not be installed."
fi 

echo "Installing "${NEWTEMP}/vpn >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 755 ${NEWTEMP}/vpn ${BINDIR} || exit 1

if [ -d "${NEWTEMP}/pixmaps" ]; then
    echo "Copying pixmaps" >> /tmp/${LOGFNAME}
    cp -R ${NEWTEMP}/pixmaps ${INSTPREFIX}
else
    echo "pixmaps not found... Continuing with the install."
fi

# if the update cache utility exists then update the menu cache
# otherwise on some gnome systems, the short cut will disappear
# after user logoff or reboot. This is neccessary on some
# gnome desktops(Ubuntu 10.04)
if [ -f "${NEWTEMP}/anyconnect.desktop" ]; then
    echo "Copying desktop shortcuts" >> /tmp/${LOGFNAME}
    ${INSTALL} -o root -m 644 ${NEWTEMP}/anyconnect.desktop /usr/share/applications 
    if [ -x "/usr/share/gnome-menus/update-gnome-menus-cache" ]; then
        for CACHE_FILE in $(ls /usr/share/applications/desktop.*.cache); do
            echo "updating ${CACHE_FILE}" >> /tmp/${LOGFNAME}
            /usr/share/gnome-menus/update-gnome-menus-cache /usr/share/applications/ > ${CACHE_FILE}
        done
    fi
else
    echo "${NEWTEMP}/anyconnect.desktop does not exist. It will not be installed."
fi

if [ -f "${NEWTEMP}/VPNManifestClient.xml" ]; then
    echo "Installing "${NEWTEMP}/VPNManifestClient.xml >> /tmp/${LOGFNAME}
    ${INSTALL} -o root -m 444 ${NEWTEMP}/VPNManifestClient.xml ${INSTPREFIX} || exit 1
else
    echo "${NEWTEMP}/VPNManifestClient.xml does not exist. It will not be installed."
fi

if [ -f "${NEWTEMP}/manifesttool" ]; then
    echo "Installing "${NEWTEMP}/manifesttool >> /tmp/${LOGFNAME}
    ${INSTALL} -o root -m 755 ${NEWTEMP}/manifesttool ${BINDIR} || exit 1
else
    echo "${NEWTEMP}/manifesttool does not exist. It will not be installed."
fi


if [ -f "${NEWTEMP}/update.txt" ]; then
    echo "Installing "${NEWTEMP}/update.txt >> /tmp/${LOGFNAME}
    ${INSTALL} -o root -m 444 ${NEWTEMP}/update.txt ${INSTPREFIX} || exit 1
else
    echo "${NEWTEMP}/update.txt does not exist. It will not be installed."
fi


if [ -f "${NEWTEMP}/vpndownloader" ]; then
    # cached downloader
    echo "Installing "${NEWTEMP}/vpndownloader >> /tmp/${LOGFNAME}
    ${INSTALL} -o root -m 755 ${NEWTEMP}/vpndownloader ${BINDIR} || exit 1

    # create a fake vpndonloader.sh that just launches the cached downloader
    # instead of self extracting the downloader like the one on the headend.
    # This method is used because of backwards compatibilty with anyconnect
    # versions before this change since they will try to invoke vpndownloader.sh
    # during weblaunch.
    echo "ERRVAL=0" > ${BINDIR}/vpndownloader.sh
    echo ${BINDIR}/"vpndownloader \"\$*\" || ERRVAL=\$?" >> ${BINDIR}/vpndownloader.sh
    echo "exit \${ERRVAL}" >> ${BINDIR}/vpndownloader.sh
    chmod 444 ${BINDIR}/vpndownloader.sh

else
    echo "${NEWTEMP}/vpndownloader does not exist. It will not be installed."
fi


# Profile schema and example template
echo "Installing "${NEWTEMP}/AnyConnectProfile.xsd >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 444 ${NEWTEMP}/AnyConnectProfile.xsd ${PROFILEDIR} || exit 1

echo "Installing "${NEWTEMP}/AnyConnectProfile.tmpl >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 444 ${NEWTEMP}/AnyConnectProfile.tmpl ${PROFILEDIR} || exit 1

echo "Installing "${NEWTEMP}/AnyConnectLocalPolicy.xsd >> /tmp/${LOGFNAME}
${INSTALL} -o root -m 444 ${NEWTEMP}/AnyConnectLocalPolicy.xsd ${INSTPREFIX} || exit 1

# Attempt to install the init script in the proper place

# Find out if we are using chkconfig
if [ -e "/sbin/chkconfig" ]; then
  CHKCONFIG="/sbin/chkconfig"
elif [ -e "/usr/sbin/chkconfig" ]; then
  CHKCONFIG="/usr/sbin/chkconfig"
else
  CHKCONFIG="chkconfig"
fi
if [ `${CHKCONFIG} --list 2> /dev/null | wc -l` -lt 1 ]; then
  CHKCONFIG=""
  echo "(chkconfig not found or not used)" >> /tmp/${LOGFNAME}
fi

# Locate the init script directory
if [ -d "/etc/init.d" ]; then
  INITD="/etc/init.d"
elif [ -d "/etc/rc.d/init.d" ]; then
  INITD="/etc/rc.d/init.d"
else
  INITD="/etc/rc.d"
fi

# BSD-style init scripts on some distributions will emulate SysV-style.
if [ "x${CHKCONFIG}" = "x" ]; then
  if [ -d "/etc/rc.d" -o -d "/etc/rc0.d" ]; then
    BSDINIT=1
    if [ -d "/etc/rc.d" ]; then
      RCD="/etc/rc.d"
    else
      RCD="/etc"
    fi
  fi
fi

if [ "x${INITD}" != "x" ]; then
  echo "Installing "${NEWTEMP}/${INIT} >> /tmp/${LOGFNAME}
  echo ${INSTALL} -o root -m 755 ${NEWTEMP}/${INIT} ${INITD} >> /tmp/${LOGFNAME}
  ${INSTALL} -o root -m 755 ${NEWTEMP}/${INIT} ${INITD} || exit 1
  if [ "x${CHKCONFIG}" != "x" ]; then
    echo ${CHKCONFIG} --add ${INIT} >> /tmp/${LOGFNAME}
    ${CHKCONFIG} --add ${INIT}
  else
    if [ "x${BSDINIT}" != "x" ]; then
      for LEVEL in ${SYSVLEVELS}; do
        DIR="rc${LEVEL}.d"
        if [ ! -d "${RCD}/${DIR}" ]; then
          mkdir ${RCD}/${DIR}
          chmod 755 ${RCD}/${DIR}
        fi
        ln -sf ${INITD}/${INIT} ${RCD}/${DIR}/${SYSVSTART}${INIT}
        ln -sf ${INITD}/${INIT} ${RCD}/${DIR}/${SYSVSTOP}${INIT}
      done
    fi
  fi

  echo "Starting the VPN agent..."
  echo "Starting the VPN agent..." >> /tmp/${LOGFNAME}
  # Attempt to start up the agent
  echo ${INITD}/${INIT} start >> /tmp/${LOGFNAME}
  logger "Starting the VPN agent..."
  ${INITD}/${INIT} start >> /tmp/${LOGFNAME} || exit 1

fi

# generate/update the VPNManifest.dat file
if [ -f ${BINDIR}/manifesttool ]; then	
   ${BINDIR}/manifesttool -i ${INSTPREFIX} ${INSTPREFIX}/VPNManifestClient.xml
fi

if [ "${RMTEMP}" = "yes" ]; then
  echo rm -rf ${TEMPDIR} >> /tmp/${LOGFNAME}
  rm -rf ${TEMPDIR}
fi

echo "Done!"
echo "Done!" >> /tmp/${LOGFNAME}

# move the logfile out of the tmp directory
mv /tmp/${LOGFNAME} ${INSTPREFIX}/.

exit 0

--BEGIN ARCHIVE--
